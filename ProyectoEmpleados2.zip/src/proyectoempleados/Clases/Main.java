
package proyectoempleados.Clases;

import proyectoempleados.Menu;


public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        
        Menu me = new Menu();
        me.setVisible(true);
        
        
        
    }
    
}
